package com.application.app.controller;


import com.application.app.model.Student;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value="/registration")
public class AppController {


    private Map <Integer,Student> students = new HashMap <Integer, Student>();

    public List<Student> studentsList = new ArrayList<Student>();

    @RequestMapping(value = "/registration", method = RequestMethod.GET)
    public String registration(Student student) {
        student.studentRegistration(student);
        studentsList= student.getStudentsList();
        if(studentsList!=null)
            return "SuccessFully Registered";
        else
            return "Not registered";
    }
    @GetMapping(value="/studentdetail/{rollno}", produces= MediaType.APPLICATION_JSON_VALUE)
    public Student getStudentDetail(@PathVariable int rollno){
        return  this.studentsList.get(rollno);
    }



    @GetMapping(value = "/studentdetail", produces= MediaType.APPLICATION_JSON_VALUE)

    public List<Student> getAll(){

        return  this.studentsList;
    }
}
