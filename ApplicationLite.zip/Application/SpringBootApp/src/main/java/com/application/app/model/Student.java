package com.application.app.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Student {

    int rollNo;
    String firstName;
    String lastName;
    String stream;
    String course;
    String address;
    int age;
    long contactNumber;
    public Map<Integer, Student> registration = new HashMap<Integer, Student>();

    public List<Student> studentsList = new ArrayList<Student>();

    public Student(int rollNo, String firstName, String lastName, String stream, String course, String address, int age, long contactNumber) {
        this.rollNo = rollNo;
        this.firstName = firstName;
        this.lastName = lastName;
        stream = stream;
        course = course;
        this.address = address;
        this.age = age;
        this.contactNumber = contactNumber;
    }


    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        stream = stream;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        course = course;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public long getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(long contactNumber) {
        this.contactNumber = contactNumber;
    }


    public void studentRegistration(Student student) {
        this.studentsList.add(student);
    }


    public List<Student> getStudentsList() {
        return studentsList;
    }

    public void setStudentsList(List<Student> studentsList) {
        this.studentsList = studentsList;
    }
}


