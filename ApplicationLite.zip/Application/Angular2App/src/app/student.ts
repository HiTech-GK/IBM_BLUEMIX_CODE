export class Student {

  constructor (
   public rollNo: number,
  public firstName:String,
  public lastName:String,
  public stream:String,
  public course:String,
  public address:String,
  public age: number,
  public contactNumber: number

  ){}

}
